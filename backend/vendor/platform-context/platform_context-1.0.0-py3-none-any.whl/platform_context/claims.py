"""Structural validation equivalent to contracts/request-context/{v1,v2}/schema.json."""

from __future__ import annotations

import re
from typing import Any

AUDIENCES = frozenset({
    "module:smart-vault", "module:kinscope", "module:hearthline", "module:spark-chat", "module:cat-rock",
    "module:life-orchestrator", "module:deep-research-engine", "module:market-hub",
})
CUSTOMER_MODULES = frozenset({"smart-vault", "kinscope", "hearthline", "spark-chat", "cat-rock"})
ROLES = frozenset({"owner", "admin", "member", "advisor"})
MAX_LIFETIME = {"user": 60, "service": 300}

_RE = {
    "jti": re.compile(r"^[A-Za-z0-9_-]{16,64}$"),
    "ws": re.compile(r"^ws_[A-Za-z0-9]{16,40}$"),
    "usr": re.compile(r"^usr_[A-Za-z0-9]{16,40}$"),
    "ses": re.compile(r"^ses_[A-Za-z0-9]{16,40}$"),
    "svc": re.compile(r"^svc:[a-z0-9-]{2,40}$"),
    "grt": re.compile(r"^grt_[A-Za-z0-9]{16,40}$"),
    "scope": re.compile(r"^[a-z0-9-]+(\.[a-z0-9-]+)*:[a-z]+$"),
    "epoch": re.compile(r"^(0|[1-9][0-9]{0,18})$"),
    "generation": re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"),
    # Origin-form target: one leading "/", visible ASCII only, no fragment, at most 2048 characters.
    "target": re.compile(r'^/[!"$-~]{0,2047}$'),
}
MAX_EPOCH = 9223372036854775807
HTTP_METHODS = frozenset({"GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"})
_COMMON = {"v", "typ", "iss", "aud", "iat", "exp", "jti", "ws"}
_USER = _COMMON | {"sid", "sub", "acr", "auth_time", "ent"}
_USER_V2 = _USER | {"epoch", "epoch_gen", "htm", "htu"}
_SERVICE = _COMMON | {"sub", "act", "scope", "purpose", "grant"}


def _int(v: Any) -> bool:
    return isinstance(v, int) and not isinstance(v, bool) and v >= 0


def _match(name: str, v: Any) -> bool:
    return isinstance(v, str) and _RE[name].fullmatch(v) is not None


def _epoch_ok(v: Any) -> bool:
    return _match("epoch", v) and int(v) <= MAX_EPOCH


def parse_claims(raw: Any, version: str = "1") -> dict[str, Any] | None:
    """Return the claims if they are a valid context of the pinned ``version`` ("1" or "2"), otherwise None.

    The version is the caller's, never the token's: a v1 parser refuses v2 claims and the reverse.
    """
    if not isinstance(raw, dict):
        return None
    c = raw
    if version not in ("1", "2") or c.get("v") != version or c.get("iss") != "platform-edge" or c.get("aud") not in AUDIENCES:
        return None
    if not (_int(c.get("iat")) and _int(c.get("exp")) and _match("jti", c.get("jti"))):
        return None
    ws = c.get("ws")
    if not isinstance(ws, dict) or set(ws) != {"id", "role"}:
        return None
    if not _match("ws", ws["id"]) or ws["role"] not in ROLES:
        return None

    if version == "2" and c.get("typ") != "user":
        return None  # v2 defines user contexts only
    if c.get("typ") == "user":
        if set(c) != (_USER_V2 if version == "2" else _USER):
            return None
        if version == "2":
            target = c["htu"]
            if not (_epoch_ok(c["epoch"]) and _match("generation", c["epoch_gen"]) and c["htm"] in HTTP_METHODS
                    and _match("target", target) and not target.startswith("//")):
                return None
        ent = c.get("ent")
        if not (_match("ses", c["sid"]) and _match("usr", c["sub"]) and c["acr"] in ("pwd", "mfa")):
            return None
        if not _int(c["auth_time"]) or not isinstance(ent, list) or len(set(map(str, ent))) != len(ent):
            return None
        if not all(m in CUSTOMER_MODULES for m in ent):
            return None
        return c
    if c.get("typ") == "service":
        required = _SERVICE - {"grant"}
        if set(c) - _SERVICE or not required <= set(c):
            return None
        act, scope, purpose = c["act"], c["scope"], c["purpose"]
        if not _match("svc", c["sub"]):
            return None
        if not isinstance(act, dict) or set(act) != {"sub"} or not _match("usr", act["sub"]):
            return None
        if not isinstance(scope, list) or not scope or len(set(map(str, scope))) != len(scope):
            return None
        if not all(_match("scope", s) for s in scope):
            return None
        if not isinstance(purpose, str) or not 3 <= len(purpose) <= 80:
            return None
        if "grant" in c and not _match("grt", c["grant"]):
            return None
        return c
    return None
