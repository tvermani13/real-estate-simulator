"""Verify and enforce platform-context/v1 and v2 (ADR 0007, 0011) in Python modules.

Modules trust only the ``X-Platform-Context`` header the session edge signs:

    verifier = Verifier(module="hearthline", jwks_url="http://127.0.0.1:9190/.well-known/platform-jwks.json")
    result = verifier.verify(request.headers.get(CONTEXT_HEADER), request.method)

A module that has been moved to v2 pins it (``Verifier(..., contract_version="2")``) and passes the request target
too: ``verifier.verify(header, method, target)``. There is no fallback between versions.

FastAPI users depend on :func:`platform_context.fastapi.require_context`.
"""

from .claims import CUSTOMER_MODULES, MAX_LIFETIME, ROLES, parse_claims
from .decide import Decision, authorize, can_access, check_token, owner_of
from .verifier import CONTEXT_HEADER, ReplayCache, ReplayCacheFull, Verifier, VerifyResult, denial_body

__all__ = [
    "CONTEXT_HEADER", "CUSTOMER_MODULES", "MAX_LIFETIME", "ROLES",
    "Decision", "ReplayCache", "ReplayCacheFull", "Verifier", "VerifyResult",
    "authorize", "can_access", "check_token", "denial_body", "owner_of", "parse_claims",
]
