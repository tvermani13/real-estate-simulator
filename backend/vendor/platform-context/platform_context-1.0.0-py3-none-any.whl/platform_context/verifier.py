"""Module-side verification of X-Platform-Context (compact JWS, ES256)."""

from __future__ import annotations

import base64
import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import OrderedDict
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature

from .claims import parse_claims
from .decide import Decision, authorize, check_token, is_unsafe

CONTEXT_HEADER = "x-platform-context"
CONTEXT_JWS_TYP = "platform-context+jwt"
CONTEXT_JWS_TYP_V2 = "platform-context-v2+jwt"


def _no_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    keys = [k for k, _ in pairs]
    if len(set(keys)) != len(keys):
        raise ValueError("duplicate member")
    return dict(pairs)


def _b64(data: str) -> bytes:
    return base64.urlsafe_b64decode(data + "=" * (-len(data) % 4))


def _public_key(jwk: dict[str, Any]) -> ec.EllipticCurvePublicKey:
    if jwk.get("kty") != "EC" or jwk.get("crv") != "P-256":
        raise ValueError("not a P-256 key")
    x, y = int.from_bytes(_b64(jwk["x"]), "big"), int.from_bytes(_b64(jwk["y"]), "big")
    return ec.EllipticCurvePublicNumbers(x, y, ec.SECP256R1()).public_key()


@dataclass(frozen=True)
class VerifyResult:
    ok: bool
    context: dict[str, Any] | None = None
    decision: Decision | None = None


class ReplayCacheFull(Exception):
    """No room to remember another jti. The write is refused: forgetting a live jti would permit a replay."""


class ReplayCache:
    """Remembers jti values until they expire, to refuse replayed unsafe requests.

    A live entry is never evicted to make room. When the cache is full of unexpired entries,
    ``check_and_record`` raises ``ReplayCacheFull`` and the request is refused."""

    def __init__(self, max_entries: int = 50_000) -> None:
        self._seen: OrderedDict[str, int] = OrderedDict()
        self._max = max_entries
        self._lock = threading.Lock()

    def check_and_record(self, jti: str, exp: int, now: int) -> bool:
        with self._lock:
            if jti in self._seen:
                return True
            if len(self._seen) >= self._max:
                for key in [k for k, e in self._seen.items() if e <= now]:
                    del self._seen[key]
                if len(self._seen) >= self._max:
                    raise ReplayCacheFull()
            self._seen[jti] = exp
            return False


_LOOPBACK_LITERALS = frozenset({"127.0.0.1", "::1"})


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *_args: Any, **_kwargs: Any) -> None:
        return None


# The key set is read from the edge on this host only: no redirects, no proxy from the environment.
_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())


def _require_loopback_url(url: str) -> None:
    parts = urllib.parse.urlsplit(url)
    if parts.scheme not in ("http", "https") or (parts.hostname or "") not in _LOOPBACK_LITERALS or parts.username or parts.password:
        raise ValueError("jwks_url must be an http(s) URL on the literal loopback address 127.0.0.1 or ::1")


class Verifier:
    """Verify contexts for one module against the edge's JWKS."""

    def __init__(
        self,
        module: str,
        *,
        jwks_url: str | None = None,
        jwks: dict[str, Any] | None = None,
        now: Callable[[], int] | None = None,
        refetch_cooldown: float = 5.0,
        cache_ttl: float = 300.0,
        max_stale: float = 3600.0,
        monotonic: Callable[[], float] = time.monotonic,
        contract_version: str = "1",
    ) -> None:
        if not (jwks_url or jwks):
            raise ValueError("Verifier needs jwks_url or jwks")
        if contract_version not in ("1", "2"):
            raise ValueError("contract_version must be '1' or '2'")
        if jwks_url:
            _require_loopback_url(jwks_url)
        # Pinned by this module's own deployment policy: a context of the other version is
        # context_invalid. There is no fallback and no negotiation.
        self.contract_version = contract_version
        self.module = module
        self._jwks_url = jwks_url
        self._now = now or (lambda: int(time.time()))
        self._cooldown = refetch_cooldown
        # Known keys are refetched after cache_ttl so a key removed at the edge stops
        # verifying; if the edge can't be reached, cached keys last at most max_stale.
        self._cache_ttl = cache_ttl
        self._max_stale = max_stale
        self._clock = monotonic
        self._last_fetch = float("-inf")
        self._loaded_at = float("-inf")
        self._keys: dict[str, ec.EllipticCurvePublicKey] = {}
        self._lock = threading.Lock()
        self.replay = ReplayCache()
        if jwks:
            self._load(jwks)
            self._loaded_at = float("inf")  # a static key set never expires

    def _load(self, jwks: dict[str, Any]) -> None:
        keys = {}
        for jwk in jwks.get("keys", []):
            if jwk.get("kid") and jwk.get("alg", "ES256") == "ES256":
                keys[jwk["kid"]] = _public_key(jwk)
        self._keys = keys

    def _refresh(self) -> None:
        """Refetch the JWKS, at most once per cooldown. Network errors keep the current keys."""
        with self._lock:
            now = self._clock()
            if now - self._last_fetch < self._cooldown:
                return
            self._last_fetch = now
            try:
                with _OPENER.open(self._jwks_url, timeout=5) as resp:  # noqa: S310 (loopback literal, checked at construction)
                    self._load(json.load(resp))
                self._loaded_at = self._clock()
            except Exception:  # noqa: BLE001 - an unusable key set keeps the current keys and fails closed when they age out
                pass

    def _key(self, kid: str) -> ec.EllipticCurvePublicKey | None:
        if self._jwks_url:
            age = self._clock() - self._loaded_at
            if age >= self._cache_ttl or kid not in self._keys:
                self._refresh()
                age = self._clock() - self._loaded_at
            if age >= self._max_stale:
                return None  # fail closed: we can no longer vouch for these keys
        return self._keys.get(kid)

    def _signature_valid(self, token: str) -> dict[str, Any] | None:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        header = json.loads(_b64(parts[0]))
        expected_typ = CONTEXT_JWS_TYP_V2 if self.contract_version == "2" else CONTEXT_JWS_TYP
        if header.get("alg") != "ES256" or header.get("typ") != expected_typ:
            return None
        key = self._key(str(header.get("kid", "")))
        raw = _b64(parts[2])
        if key is None or len(raw) != 64:
            return None
        der = encode_dss_signature(int.from_bytes(raw[:32], "big"), int.from_bytes(raw[32:], "big"))
        try:
            key.verify(der, f"{parts[0]}.{parts[1]}".encode(), ec.ECDSA(hashes.SHA256()))
        except InvalidSignature:
            return None
        # Two members with one name would let two readers see different values in the same signed bytes.
        return json.loads(_b64(parts[1]), object_pairs_hook=_no_duplicates)

    def verify(self, header: str | None, method: str | None = "GET", target: str | None = None) -> VerifyResult:
        """Verify a header value. A v2 verifier also needs the request ``target`` (path and query exactly as
        this module received it) and refuses a context minted for another method or target."""
        if not header:
            return VerifyResult(False, decision=Decision(False, 401, "context_missing"))
        try:
            payload = self._signature_valid(header)
        except Exception:  # noqa: BLE001 - any malformed token or key material is context_invalid, never a 500
            payload = None
        context = parse_claims(payload, self.contract_version) if payload is not None else None
        if context is None:
            return VerifyResult(False, decision=Decision(False, 401, "context_invalid"))
        # The context is only good for the request it was minted for: a read context cannot authorize a write.
        if context["v"] == "2" and (target is None or context["htm"] != (method or "GET").upper() or context["htu"] != target):
            return VerifyResult(False, decision=Decision(False, 401, "context_invalid"))
        now = self._now()
        pre = check_token(context, self.module, now)
        if not pre.allow:
            return VerifyResult(False, decision=pre)
        if is_unsafe(method):
            try:
                replayed = self.replay.check_and_record(context["jti"], context["exp"], now)
            except ReplayCacheFull:
                return VerifyResult(False, decision=Decision(False, 503, "context_unavailable"))
            if replayed:
                return VerifyResult(False, decision=Decision(False, 401, "context_replayed"))
        return VerifyResult(True, context=context)

    def decide(self, header: str | None, request: dict[str, Any]) -> tuple[Decision, dict[str, Any] | None]:
        """Verify and authorize in the contract's order. ``request`` omits ``module``."""
        result = self.verify(header, request.get("method"), request.get("target"))
        if not result.ok:
            return result.decision, None  # type: ignore[return-value]
        decision = authorize(result.context, {**request, "module": self.module}, self._now())  # type: ignore[arg-type]
        return decision, result.context if decision.allow else None


_MESSAGES = {
    "context_missing": "Sign in to continue.",
    "context_invalid": "Your session could not be verified. Sign in again.",
    "context_expired": "Your session check expired. Retry the request.",
    "audience_mismatch": "This request was not issued for this app.",
    "context_replayed": "This request was already used. Retry it.",
    "module_not_entitled": "Your workspace does not include this app.",
    "scope_insufficient": "This service is not allowed to do that.",
    "role_insufficient": "Your role in this workspace does not allow that.",
    "step_up_required": "Confirm your identity to continue.",
    "not_found": "Not found.",
    "not_owner": "Only the owner can change this.",
}


def denial_body(decision: Decision, **extra: Any) -> dict[str, Any]:
    """Error body per the contract; never says whether a record exists elsewhere."""
    return {"error": {"code": decision.code, "message": _MESSAGES.get(decision.code or "", "Denied."), **extra}}
