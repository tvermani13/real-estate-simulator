"""Decision rules of platform-context/v1, in the contract table's order."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .claims import CUSTOMER_MODULES, MAX_LIFETIME

CLOCK_SKEW = 5
UNSAFE_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"})


@dataclass(frozen=True)
class Decision:
    allow: bool
    status: int | None = None
    code: str | None = None


ALLOW = Decision(True)


def _deny(status: int, code: str) -> Decision:
    return Decision(False, status, code)


def is_unsafe(method: str | None) -> bool:
    return (method or "GET").upper() in UNSAFE_METHODS


def check_token(ctx: dict[str, Any], module: str, now: int, replayed: bool = False) -> Decision:
    """Lifetime, expiry, audience and replay, after signature and structure."""
    if ctx["exp"] - ctx["iat"] > MAX_LIFETIME[ctx["typ"]] or ctx["iat"] > now + CLOCK_SKEW:
        return _deny(401, "context_invalid")
    if now >= ctx["exp"]:
        return _deny(401, "context_expired")
    if ctx["aud"] != f"module:{module}":
        return _deny(401, "audience_mismatch")
    if replayed:
        return _deny(401, "context_replayed")
    return ALLOW


def owner_of(ctx: dict[str, Any]) -> str:
    """The subject that owns records this request creates (ADR 0008)."""
    return ctx["sub"] if ctx["typ"] == "user" else ctx["act"]["sub"]


def can_access(ctx: dict[str, Any], resource: dict[str, Any], method: str | None = "GET") -> Decision:
    """Other workspaces and others' private records are 404; shared records are read-only."""
    if resource["workspace_id"] != ctx["ws"]["id"]:
        return _deny(404, "not_found")
    if resource["owner_sub"] != owner_of(ctx):
        if not resource.get("shared", False):
            return _deny(404, "not_found")
        if is_unsafe(method):
            return _deny(403, "not_owner")
    return ALLOW


def authorize(ctx: dict[str, Any], request: dict[str, Any], now: int) -> Decision:
    """Entitlement, scope, role, step-up, then record ownership."""
    module = request["module"]
    if ctx["typ"] == "user" and module in CUSTOMER_MODULES and module not in ctx["ent"]:
        return _deny(403, "module_not_entitled")
    if ctx["typ"] == "service" and request["action"] not in ctx["scope"]:
        return _deny(403, "scope_insufficient")
    requires = request.get("requires") or {}
    if "role" in requires and ctx["ws"]["role"] not in requires["role"]:
        return _deny(403, "role_insufficient")
    if ctx["typ"] == "user" and "acr" in requires:
        fresh = now - ctx["auth_time"] <= requires.get("max_age", 10**12)
        if ctx["acr"] != requires["acr"] or not fresh:
            return _deny(403, "step_up_required")
    resource = request.get("resource")
    return can_access(ctx, resource, request.get("method")) if resource is not None else ALLOW
