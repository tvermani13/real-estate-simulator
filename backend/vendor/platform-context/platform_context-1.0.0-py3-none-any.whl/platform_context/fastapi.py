"""FastAPI dependency: every route that depends on it gets a verified context or a contract denial.

    verifier = Verifier("hearthline", jwks_url=settings.platform_jwks_url)
    install_exception_handler(app)          # denials use the contract's {"error": {...}} body
    PlatformContext = Annotated[dict, Depends(require_context(verifier))]

    @app.get("/api/scenarios")
    def list_scenarios(ctx: PlatformContext): ...
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse

from .decide import Decision
from .verifier import CONTEXT_HEADER, Verifier, denial_body


class PlatformContextDenied(HTTPException):
    """A contract denial. With `install_exception_handler`, the response body is exactly
    `denial_body(decision)`; without it, FastAPI still returns the right status code."""

    def __init__(self, decision: Decision) -> None:
        self.decision = decision
        super().__init__(
            status_code=decision.status or 401,
            detail=denial_body(decision)["error"],
            headers={"Cache-Control": "no-store"},
        )


async def _handle_denied(_request: Request, exc: PlatformContextDenied) -> JSONResponse:
    return JSONResponse(status_code=exc.status_code, content=denial_body(exc.decision), headers={"Cache-Control": "no-store"})


def install_exception_handler(app: FastAPI) -> None:
    """Return contract denials as `{"error": {"code", "message"}}`, matching the TypeScript adapter."""
    app.add_exception_handler(PlatformContextDenied, _handle_denied)  # type: ignore[arg-type]


def require_context(verifier: Verifier) -> Callable[[Request], dict[str, Any]]:
    def dependency(request: Request) -> dict[str, Any]:
        # The target a v2 context is bound to: the raw path and query as received, never decoded.
        raw = request.scope.get("raw_path")
        path = raw.decode("latin-1") if isinstance(raw, bytes) else request.url.path
        query = request.scope.get("query_string", b"").decode("latin-1")
        result = verifier.verify(request.headers.get(CONTEXT_HEADER), request.method, f"{path}?{query}" if query else path)
        if not result.ok:
            raise PlatformContextDenied(result.decision)  # type: ignore[arg-type]
        return result.context  # type: ignore[return-value]

    return dependency
